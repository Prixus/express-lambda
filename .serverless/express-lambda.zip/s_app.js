
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'prixus1231',
  applicationName: 'express-lambda',
  appUid: 'yQy4rMhK9xhdB9jQHY',
  orgUid: '1756d84a-55f8-4aed-97b7-54772021beb5',
  deploymentUid: '83564644-70a5-4022-80e1-4d23cde6dba0',
  serviceName: 'express-lambda',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.0.5',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'express-lambda-dev-app', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}